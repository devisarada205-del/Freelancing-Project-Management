'use strict';
/**
 * FreelanceHub backend: Node.js (v16+), zero dependencies.
 *
 *   node server.js            -> http://localhost:3000
 *
 * - REST API under /api/*  (JSON)
 * - Serves index.html (the frontend) at /
 * - Data persisted to data.json next to this file (override with DATA_FILE)
 * - Passwords hashed with scrypt; session tokens stored only as SHA-256 hashes
 * - Every user only ever sees their own clients, projects, tasks and payments
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT) || 3000;
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const INDEX_FILE = path.join(__dirname, 'index.html');
const SESSION_TTL_MS = 14 * 24 * 60 * 60 * 1000;
const DEMO_TTL_MS = 2 * 24 * 60 * 60 * 1000;
const MAX_BODY_BYTES = 1_000_000;

/* ------------------------------------------------------------------ */
/* Persistence                                                         */
/* ------------------------------------------------------------------ */

let db = { users: [], sessions: {}, workspaces: {} };

function loadDb() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    db = {
      users: Array.isArray(parsed.users) ? parsed.users : [],
      sessions: parsed.sessions && typeof parsed.sessions === 'object' ? parsed.sessions : {},
      workspaces: parsed.workspaces && typeof parsed.workspaces === 'object' ? parsed.workspaces : {},
    };
  } catch (err) {
    if (err.code !== 'ENOENT') console.error('Could not read data file, starting empty:', err.message);
  }
  prune();
}

function saveDb() {
  const tmp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DATA_FILE);
}

/** Remove expired sessions and old demo accounts. */
function prune() {
  const now = Date.now();
  let changed = false;
  for (const [key, s] of Object.entries(db.sessions)) {
    if (s.expires < now) {
      delete db.sessions[key];
      changed = true;
    }
  }
  const stale = db.users.filter((u) => u.demo && now - u.createdAt > DEMO_TTL_MS).map((u) => u.id);
  if (stale.length) {
    db.users = db.users.filter((u) => !stale.includes(u.id));
    for (const id of stale) delete db.workspaces[id];
    for (const [key, s] of Object.entries(db.sessions)) {
      if (stale.includes(s.userId)) delete db.sessions[key];
    }
    changed = true;
  }
  if (changed) saveDb();
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const uid = () => crypto.randomBytes(8).toString('hex');
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

function pad(n) {
  return String(n).padStart(2, '0');
}
function isoDate(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function shiftDate(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return isoDate(d);
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const isDate = (v) => typeof v === 'string' && DATE_RE.test(v) && !Number.isNaN(Date.parse(v));
const isStr = (v, min, max) => typeof v === 'string' && v.length >= min && v.length <= max;
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);

function hashPassword(password, saltHex) {
  const salt = saltHex ? Buffer.from(saltHex, 'hex') : crypto.randomBytes(16);
  const hash = crypto.scryptSync(password, salt, 64);
  return { salt: salt.toString('hex'), hash: hash.toString('hex') };
}

function verifyPassword(password, user) {
  const { hash } = hashPassword(password, user.salt);
  const a = Buffer.from(hash, 'hex');
  const b = Buffer.from(user.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.sessions[sha256(token)] = { userId, expires: Date.now() + SESSION_TTL_MS };
  return token;
}

function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, demo: !!u.demo };
}

function authenticate(req) {
  const header = req.headers.authorization || '';
  const match = /^Bearer ([a-f0-9]{64})$/.exec(header);
  if (!match) throw new HttpError(401, 'Please log in.');
  const session = db.sessions[sha256(match[1])];
  if (!session || session.expires < Date.now()) throw new HttpError(401, 'Your session has expired. Please log in again.');
  const user = db.users.find((u) => u.id === session.userId);
  if (!user) throw new HttpError(401, 'Account not found.');
  return { user, tokenKey: sha256(match[1]) };
}

function workspaceOf(userId) {
  if (!db.workspaces[userId]) db.workspaces[userId] = { clients: [], projects: [], tasks: [], payments: [] };
  return db.workspaces[userId];
}

/* Simple per-IP limiter for login/register attempts */
const attempts = new Map();
function rateLimit(req) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const entry = attempts.get(ip);
  if (!entry || entry.reset < now) {
    attempts.set(ip, { count: 1, reset: now + 15 * 60 * 1000 });
    return;
  }
  entry.count += 1;
  if (entry.count > 30) throw new HttpError(429, 'Too many attempts. Try again in a few minutes.');
}

/* ------------------------------------------------------------------ */
/* Validation schemas for the four resources                           */
/* ------------------------------------------------------------------ */

const STATUSES = ['Active', 'On hold', 'Completed'];
const PRIORITIES = ['Low', 'Medium', 'High'];
const TASK_STATUSES = ['To Do', 'In Progress', 'Done'];

const SCHEMAS = {
  clients: {
    name: { req: true, check: (v) => isStr(v, 1, 120) },
    contact: { def: '', check: (v) => isStr(v, 0, 120) },
    email: { def: '', check: (v) => v === '' || (isStr(v, 3, 200) && EMAIL_RE.test(v)) },
    notes: { def: '', check: (v) => isStr(v, 0, 500) },
  },
  projects: {
    clientId: { req: true, check: (v, ws) => ws.clients.some((c) => c.id === v) },
    name: { req: true, check: (v) => isStr(v, 1, 160) },
    status: { def: 'Active', check: (v) => STATUSES.includes(v) },
    priority: { def: 'Medium', check: (v) => PRIORITIES.includes(v) },
    deadline: { req: true, check: isDate },
    budget: { req: true, check: (v) => isNum(v) && v >= 0 && v <= 1e11 },
  },
  tasks: {
    projectId: { req: true, check: (v, ws) => ws.projects.some((p) => p.id === v) },
    title: { req: true, check: (v) => isStr(v, 1, 200) },
    status: { def: 'To Do', check: (v) => TASK_STATUSES.includes(v) },
    due: { def: '', check: (v) => v === '' || isDate(v) },
  },
  payments: {
    projectId: { req: true, check: (v, ws) => ws.projects.some((p) => p.id === v) },
    amount: { req: true, check: (v) => isNum(v) && v > 0 && v <= 1e11 },
    due: { req: true, check: isDate },
    receivedOn: { def: null, check: (v) => v === null || isDate(v) },
  },
};

/** Validate a request body for `kind`. `existing` => PATCH (partial update). */
function buildRecord(kind, body, ws, existing) {
  const schema = SCHEMAS[kind];
  const input = body && typeof body === 'object' && !Array.isArray(body) ? body : {};
  const out = {};
  for (const [key, field] of Object.entries(schema)) {
    if (!Object.prototype.hasOwnProperty.call(input, key)) {
      if (existing) {
        out[key] = existing[key];
      } else if (field.req) {
        throw new HttpError(400, `"${key}" is required.`);
      } else {
        out[key] = field.def;
      }
      continue;
    }
    let value = input[key];
    if (typeof value === 'string') value = value.trim();
    if (!field.check(value, ws)) throw new HttpError(400, `"${key}" is not valid.`);
    out[key] = value;
  }
  return out;
}

function removeProjects(ws, projectIds) {
  ws.projects = ws.projects.filter((p) => !projectIds.includes(p.id));
  ws.tasks = ws.tasks.filter((t) => !projectIds.includes(t.projectId));
  ws.payments = ws.payments.filter((p) => !projectIds.includes(p.projectId));
}

function deleteRecord(kind, id, ws) {
  const exists = ws[kind].some((r) => r.id === id);
  if (!exists) throw new HttpError(404, 'Not found.');
  if (kind === 'clients') {
    const projectIds = ws.projects.filter((p) => p.clientId === id).map((p) => p.id);
    removeProjects(ws, projectIds);
    ws.clients = ws.clients.filter((c) => c.id !== id);
  } else if (kind === 'projects') {
    removeProjects(ws, [id]);
  } else {
    ws[kind] = ws[kind].filter((r) => r.id !== id);
  }
}

/* ------------------------------------------------------------------ */
/* Reports                                                             */
/* ------------------------------------------------------------------ */

function summarize(ws, today) {
  const sum = (list) => list.reduce((s, x) => s + x.amount, 0);
  const received = sum(ws.payments.filter((p) => p.receivedOn));
  const outstanding = sum(ws.payments.filter((p) => !p.receivedOn));
  const overduePayments = ws.payments.filter((p) => !p.receivedOn && p.due < today).length;
  const overdueTasks = ws.tasks.filter((t) => t.status !== 'Done' && t.due && t.due < today).length;
  const doneTasks = ws.tasks.filter((t) => t.status === 'Done').length;

  const [ty, tm] = today.split('-').map(Number);
  const monthly = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(ty, tm - 1 - i, 1);
    const key = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
    const total = sum(ws.payments.filter((p) => p.receivedOn && p.receivedOn.startsWith(key)));
    monthly.push({ month: key, total });
  }

  const upcoming = ws.projects
    .filter((p) => p.status === 'Active')
    .sort((a, b) => a.deadline.localeCompare(b.deadline))
    .slice(0, 5)
    .map((p) => ({ id: p.id, name: p.name, deadline: p.deadline }));

  return {
    activeProjects: ws.projects.filter((p) => p.status === 'Active').length,
    received,
    outstanding,
    overdueTasks,
    overduePayments,
    completionRate: ws.tasks.length ? Math.round((doneTasks / ws.tasks.length) * 100) : 0,
    monthly,
    upcoming,
  };
}

function csvCell(v) {
  let s = String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; // neutralise spreadsheet formulas
  return `"${s.replace(/"/g, '""')}"`;
}
function toCsv(rows) {
  return rows.map((r) => r.map(csvCell).join(',')).join('\r\n');
}

function exportCsv(kind, ws) {
  const clientName = (id) => (ws.clients.find((c) => c.id === id) || {}).name || '';
  if (kind === 'payments') {
    const today = isoDate(new Date());
    const rows = [['Project', 'Client', 'Amount (INR)', 'Expected', 'Received', 'Status']];
    for (const p of ws.payments) {
      const project = ws.projects.find((x) => x.id === p.projectId) || {};
      const status = p.receivedOn ? 'Paid' : p.due < today ? 'Overdue' : 'Pending';
      rows.push([project.name || '', clientName(project.clientId), p.amount, p.due, p.receivedOn || '', status]);
    }
    return toCsv(rows);
  }
  const rows = [['Project', 'Client', 'Status', 'Priority', 'Deadline', 'Budget (INR)', 'Received (INR)', 'Balance (INR)']];
  for (const p of ws.projects) {
    const got = ws.payments.filter((y) => y.projectId === p.id && y.receivedOn).reduce((s, y) => s + y.amount, 0);
    rows.push([p.name, clientName(p.clientId), p.status, p.priority, p.deadline, p.budget, got, Math.max(0, p.budget - got)]);
  }
  return toCsv(rows);
}

/* ------------------------------------------------------------------ */
/* Demo data                                                           */
/* ------------------------------------------------------------------ */

function seedWorkspace() {
  const c = (id, name, contact, email, notes) => ({ id, name, contact, email, notes });
  return {
    clients: [
      c('c1', 'Trekwise', 'Aarav Mehta', 'aarav@trekwise.example', 'Prefers WhatsApp updates.'),
      c('c2', 'Brightleaf', 'Sana Qureshi', 'sana@brightleaf.example', 'Brand refresh, quarterly retainer.'),
      c('c3', 'Chaiwala', 'Rohan Iyer', 'rohan@chaiwala.example', 'Payments often run late.'),
      c('c4', 'Northpeak Labs', 'Meera Nair', 'meera@northpeak.example', ''),
    ],
    projects: [
      { id: 'p1', clientId: 'c1', name: 'Trekwise booking app', status: 'Active', priority: 'High', deadline: shiftDate(4), budget: 320000 },
      { id: 'p2', clientId: 'c2', name: 'Brightleaf redesign', status: 'Active', priority: 'Medium', deadline: shiftDate(9), budget: 240000 },
      { id: 'p3', clientId: 'c3', name: 'Chaiwala launch', status: 'Active', priority: 'High', deadline: shiftDate(-3), budget: 280000 },
      { id: 'p4', clientId: 'c4', name: 'Northpeak dashboard', status: 'Active', priority: 'Low', deadline: shiftDate(21), budget: 230000 },
    ],
    tasks: [
      { id: 't1', projectId: 'p1', title: 'Build booking calendar', status: 'In Progress', due: shiftDate(2) },
      { id: 't2', projectId: 'p1', title: 'Payment gateway setup', status: 'To Do', due: shiftDate(-1) },
      { id: 't3', projectId: 'p1', title: 'Kickoff call', status: 'Done', due: shiftDate(-20) },
      { id: 't4', projectId: 'p2', title: 'Moodboard review', status: 'In Progress', due: shiftDate(5) },
      { id: 't5', projectId: 'p2', title: 'Collect brand assets', status: 'To Do', due: shiftDate(3) },
      { id: 't6', projectId: 'p3', title: 'Menu page QA', status: 'To Do', due: shiftDate(-5) },
      { id: 't7', projectId: 'p3', title: 'Launch checklist', status: 'In Progress', due: shiftDate(-2) },
      { id: 't8', projectId: 'p3', title: 'Domain setup', status: 'Done', due: shiftDate(-12) },
      { id: 't9', projectId: 'p4', title: 'Wireframe dashboard', status: 'To Do', due: shiftDate(10) },
    ],
    payments: [
      { id: 'y1', projectId: 'p1', amount: 150000, due: shiftDate(-22), receivedOn: shiftDate(-20) },
      { id: 'y2', projectId: 'p3', amount: 140000, due: shiftDate(-12), receivedOn: shiftDate(-10) },
      { id: 'y3', projectId: 'p2', amount: 150000, due: shiftDate(-40), receivedOn: shiftDate(-38) },
      { id: 'y4', projectId: 'p2', amount: 90000, due: shiftDate(6), receivedOn: null },
      { id: 'y5', projectId: 'p3', amount: 140000, due: shiftDate(-2), receivedOn: null },
      { id: 'y6', projectId: 'p1', amount: 170000, due: shiftDate(15), receivedOn: null },
      { id: 'y7', projectId: 'p4', amount: 230000, due: shiftDate(25), receivedOn: null },
    ],
  };
}

/* ------------------------------------------------------------------ */
/* HTTP plumbing                                                       */
/* ------------------------------------------------------------------ */

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, { ...SECURITY_HEADERS, ...headers });
  res.end(body);
}

function sendJson(res, status, payload) {
  send(res, status, JSON.stringify(payload), {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new HttpError(413, 'Request body too large.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (size === 0) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new HttpError(400, 'Request body must be valid JSON.'));
      }
    });
    req.on('error', reject);
  });
}

function startSession(res, user, status = 200) {
  const token = createSession(user.id);
  saveDb();
  sendJson(res, status, { token, user: publicUser(user) });
}

/* ------------------------------------------------------------------ */
/* Routes                                                              */
/* ------------------------------------------------------------------ */

async function handleApi(req, res, url) {
  const method = req.method;
  const parts = url.pathname.split('/').filter(Boolean).slice(1); // drop "api"
  const [root, id] = parts;

  /* ---- public auth routes ---- */
  if (method === 'POST' && root === 'register' && parts.length === 1) {
    rateLimit(req);
    const body = await readJson(req);
    const name = typeof body.name === 'string' ? body.name.trim() : '';
    const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
    const password = typeof body.password === 'string' ? body.password : '';
    if (!isStr(name, 1, 80)) throw new HttpError(400, 'Enter your name.');
    if (!EMAIL_RE.test(email) || email.length > 200) throw new HttpError(400, 'Enter a valid email address.');
    if (!isStr(password, 6, 200)) throw new HttpError(400, 'Use a password of at least 6 characters.');
    if (db.users.some((u) => u.email === email)) throw new HttpError(409, 'An account with this email already exists. Log in instead.');
    const user = { id: uid(), name, email, ...hashPassword(password), createdAt: Date.now() };
    db.users.push(user);
    workspaceOf(user.id);
    return startSession(res, user, 201);
  }

  if (method === 'POST' && root === 'login' && parts.length === 1) {
    rateLimit(req);
    const body = await readJson(req);
    const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
    const password = typeof body.password === 'string' ? body.password : '';
    const user = db.users.find((u) => u.email === email);
    if (!user || !verifyPassword(password, user)) throw new HttpError(401, 'Email or password is incorrect.');
    return startSession(res, user);
  }

  if (method === 'POST' && root === 'demo' && parts.length === 1) {
    rateLimit(req);
    prune();
    const user = {
      id: uid(),
      name: 'Demo Freelancer',
      email: `demo-${uid()}@demo.local`,
      ...hashPassword(crypto.randomBytes(18).toString('hex')),
      createdAt: Date.now(),
      demo: true,
    };
    db.users.push(user);
    db.workspaces[user.id] = seedWorkspace();
    return startSession(res, user, 201);
  }

  /* ---- everything below needs a valid session ---- */
  const { user, tokenKey } = authenticate(req);
  const ws = workspaceOf(user.id);

  if (method === 'GET' && root === 'me' && parts.length === 1) {
    return sendJson(res, 200, { user: publicUser(user) });
  }

  if (method === 'POST' && root === 'logout' && parts.length === 1) {
    delete db.sessions[tokenKey];
    saveDb();
    return sendJson(res, 200, { ok: true });
  }

  if (method === 'GET' && root === 'summary' && parts.length === 1) {
    const requested = url.searchParams.get('today');
    const today = requested && isDate(requested) ? requested : isoDate(new Date());
    return sendJson(res, 200, summarize(ws, today));
  }

  if (method === 'GET' && root === 'export' && (id === 'payments' || id === 'projects') && parts.length === 2) {
    return send(res, 200, exportCsv(id, ws), {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${id}.csv"`,
      'Cache-Control': 'no-store',
    });
  }

  if (Object.prototype.hasOwnProperty.call(SCHEMAS, root)) {
    const kind = root;
    if (parts.length === 1) {
      if (method === 'GET') return sendJson(res, 200, ws[kind]);
      if (method === 'POST') {
        const record = { id: uid(), ...buildRecord(kind, await readJson(req), ws, null) };
        ws[kind].push(record);
        saveDb();
        return sendJson(res, 201, record);
      }
    } else if (parts.length === 2) {
      if (method === 'GET') {
        const found = ws[kind].find((r) => r.id === id);
        if (!found) throw new HttpError(404, 'Not found.');
        return sendJson(res, 200, found);
      }
      if (method === 'PATCH') {
        const existing = ws[kind].find((r) => r.id === id);
        if (!existing) throw new HttpError(404, 'Not found.');
        const updated = buildRecord(kind, await readJson(req), ws, existing);
        Object.assign(existing, updated);
        saveDb();
        return sendJson(res, 200, existing);
      }
      if (method === 'DELETE') {
        deleteRecord(kind, id, ws);
        saveDb();
        return sendJson(res, 200, { ok: true });
      }
    }
  }

  throw new HttpError(404, 'Unknown API route.');
}

function serveIndex(res) {
  fs.readFile(INDEX_FILE, (err, html) => {
    if (err) return send(res, 500, 'index.html not found next to server.js', { 'Content-Type': 'text/plain; charset=utf-8' });
    send(res, 200, html, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) {
      await handleApi(req, res, url);
      return;
    }
    if ((req.method === 'GET' || req.method === 'HEAD') && (url.pathname === '/' || url.pathname === '/index.html')) {
      serveIndex(res);
      return;
    }
    send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
  } catch (err) {
    if (err instanceof HttpError) {
      sendJson(res, err.status, { error: err.message });
    } else {
      console.error(err);
      sendJson(res, 500, { error: 'Something went wrong on the server.' });
    }
  }
});

if (require.main === module) {
  loadDb();
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`Port ${PORT} is already in use. Close the other program, or use another port:`);
      console.error('  macOS/Linux:        PORT=3001 node server.js');
      console.error('  Windows PowerShell: $env:PORT=3001; node server.js');
      process.exit(1);
    }
    throw err;
  });
  server.listen(PORT, () => {
    console.log(`FreelanceHub running at http://localhost:${PORT}`);
  });
}

module.exports = { server, loadDb };
