# FreelanceHub

Clients, projects, tasks and payments (in ₹) for freelancers.
Backend: `server.js` (Node.js, no packages to install). Frontend: `index.html`.

## Run in VS Code

1. Install Node.js LTS (version 16 or newer) from https://nodejs.org
2. In VS Code: File > Open Folder... and choose this `freelancehub` folder.
3. Start the server, either way:
   - Press **F5** (choose "Start FreelanceHub" if asked), or
   - Open a terminal (Terminal > New Terminal) and run: `npm start`
4. Open http://localhost:3000 in your browser.

Stop the server with Shift+F5 (debugger) or Ctrl+C (terminal).

## Important

- Always open the app through http://localhost:3000. Opening `index.html` directly
  from disk, or with the Live Server extension, will NOT work, because the backend
  serves the API and the page together.
- No `npm install` is needed: there are no dependencies.

## Troubleshooting

- "node is not recognized": install Node.js, then restart VS Code.
- "Port 3000 is already in use": run on another port.
  macOS/Linux: `PORT=3001 node server.js`
  Windows PowerShell: `$env:PORT=3001; node server.js`
  then open http://localhost:3001
- Start fresh: stop the server and delete `data.json`.

## Notes

- Data is saved in `data.json` next to `server.js`.
- Passwords are hashed and each account only sees its own data.
- The server uses plain HTTP, so keep it on your own computer or put it behind HTTPS
  before exposing it on the internet.
